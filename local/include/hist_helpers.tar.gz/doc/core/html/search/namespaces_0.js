var searchData=
[
  ['histutils',['HistUtils',['../namespaceHistUtils.html',1,'']]]
];
