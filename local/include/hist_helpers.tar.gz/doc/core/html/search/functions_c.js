var searchData=
[
  ['remove',['remove',['../classHistUtils_1_1HistMgr.html#a0f2238621b12aa2e768f804344d15915',1,'HistUtils::HistMgr']]]
];
