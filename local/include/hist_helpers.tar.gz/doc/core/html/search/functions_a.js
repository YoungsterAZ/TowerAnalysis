var searchData=
[
  ['mean',['mean',['../namespaceHistUtils.html#af92ee23ad35cba919099610d716bbb93',1,'HistUtils']]]
];
