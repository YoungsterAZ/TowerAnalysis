var searchData=
[
  ['instance',['instance',['../classHistUtils_1_1HistMgr.html#a470a4d54f8b7f7e305aa43fb48f99e9c',1,'HistUtils::HistMgr']]]
];
