var searchData=
[
  ['mean',['Mean',['../namespaceHistUtils.html#aee957b08165ec79d9ab22d3985938110ae57ec394e887bc7762c6476186d7eaf8',1,'HistUtils']]],
  ['median',['Median',['../namespaceHistUtils.html#aee957b08165ec79d9ab22d3985938110abf140a74893a9708698f76a4ee416789',1,'HistUtils']]]
];
