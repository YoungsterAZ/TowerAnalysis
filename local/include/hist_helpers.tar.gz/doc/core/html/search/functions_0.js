var searchData=
[
  ['add',['add',['../classHistUtils_1_1HistMgr.html#a0ddb91771b282ca41a4b7b916f8e7e2c',1,'HistUtils::HistMgr']]]
];
