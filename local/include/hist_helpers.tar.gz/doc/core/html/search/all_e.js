var searchData=
[
  ['scale2d',['scale2D',['../namespaceHistUtils.html#ad08060ea4a76cdf48a806c40b4374954',1,'HistUtils']]],
  ['stats',['stats',['../namespaceHistUtils.html#a75d5e50c598254d5415d2b2e1919eae9',1,'HistUtils::stats(TH1D *h, double &amp;m, double &amp;dm, Stats s=Mean)'],['../namespaceHistUtils.html#a0ae5e8fb9c5a958bacd0827d3d05a7bf',1,'HistUtils::stats(TH1D *h, double &amp;m, double &amp;dl, double &amp;dh, Stats s=Mean)'],['../namespaceHistUtils.html#aee957b08165ec79d9ab22d3985938110',1,'HistUtils::Stats()']]],
  ['stats_5flu',['stats_lu',['../namespaceHistUtils.html#aa3bb9be93085f86cfa38e98f525f525b',1,'HistUtils']]]
];
