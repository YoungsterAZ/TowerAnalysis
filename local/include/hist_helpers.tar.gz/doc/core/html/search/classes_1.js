var searchData=
[
  ['histmgr',['HistMgr',['../classHistUtils_1_1HistMgr.html',1,'HistUtils']]]
];
