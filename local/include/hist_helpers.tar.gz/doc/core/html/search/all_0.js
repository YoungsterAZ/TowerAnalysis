var searchData=
[
  ['_5fhlist',['_hlist',['../classHistUtils_1_1HistMgr.html#a2f35b5aff01c50080e7ea59309f69842',1,'HistUtils::HistMgr']]],
  ['_5finstance',['_instance',['../classHistUtils_1_1HistMgr.html#a9941e8757f5e3dabfc24422822857fe6',1,'HistUtils::HistMgr']]]
];
